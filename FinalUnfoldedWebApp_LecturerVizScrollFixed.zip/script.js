const firebaseConfig={apiKey:"AIzaSyD428bnIj-ay5-MF2PECJjy1yfqt3U1e0o",authDomain:"unfolded-3f83a.firebaseapp.com",databaseURL:"https://unfolded-3f83a-default-rtdb.firebaseio.com",projectId:"unfolded-3f83a",storageBucket:"unfolded-3f83a.firebasestorage.app",messagingSenderId:"214514199829",appId:"1:214514199829:web:58d8a218026e150aff0d1c"};
firebase.initializeApp(firebaseConfig);const database=firebase.database(),auth=firebase.auth(),CLASS_ID="unfolded-demo-class",LECTURER_PIN="123",app=document.getElementById("app"),toastHost=document.getElementById("toastHost"),confettiHost=document.getElementById("confettiHost");
auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL).catch(e=>console.warn("Auth persistence could not be set",e));
const state={view:"studentStart",sessionMode:"recorded",name:"",sessionTitle:"",lectureFile:null,lectureURL:"",joinedLive:false,activeLecture:null,currentStartedAt:null,markers:[],reflections:{},shareSettings:{},questionnaireAnswers:{},mediaRecorder:null,recordedChunks:[],localRecordingURL:"",lecturerQuestions:["","","","",""],submissions:[],selectedStudent:"all",selectedViz:"combined",timerId:null,submitted:false,noteFiles:[],recordedPauseQuestions:[],recordedQuestionnaire:["","","","",""],recordedQuestionnaireEnabled:true,pauseAnswers:{},replayedMarkers:{},studentAuth:null,lecturerAuth:null,studentSavedSessions:{},sessionRunId:null};
let preserveNextScroll=false;
const APP_STATE_KEY="unfoldedAppStateV2";
function saveAppState(){
  try{
    const safeViews=["studentProfile","lecture","review","lecturer","lecturerLogin","studentLogin"];
    localStorage.setItem(APP_STATE_KEY, JSON.stringify({
      view:safeViews.includes(state.view)?state.view:(state.studentAuth?"studentProfile":"studentLogin"),
      sessionMode:state.sessionMode,
      joinedLive:!!state.joinedLive,
      sessionTitle:state.sessionTitle||"",
      name:state.name||"",
      currentStartedAt:state.currentStartedAt||null,
      savedAt:Date.now()
    }));
  }catch(e){}
}
function loadAppState(){
  try{return JSON.parse(localStorage.getItem(APP_STATE_KEY)||"null")||{}}catch(e){return {}}
}
function clearAppState(){try{localStorage.removeItem(APP_STATE_KEY)}catch(e){}}
function restoreAppStateAfterAuth(){
  const saved=loadAppState();
  if(saved.name)state.name=saved.name;
  if(saved.sessionTitle)state.sessionTitle=saved.sessionTitle;
  if(saved.currentStartedAt)state.currentStartedAt=saved.currentStartedAt;
  if(saved.sessionMode)state.sessionMode=saved.sessionMode;
  state.joinedLive=!!saved.joinedLive;
  const studentViews=["studentProfile","lecture","review"];
  if(state.lecturerAuth){
    state.view=saved.view==="lecturer"?"lecturer":"lecturer";
  }else if(state.studentAuth){
    state.view=studentViews.includes(saved.view)?saved.view:"studentProfile";
    if(state.view==="lecture"&&state.sessionMode==="recorded"&&!state.lectureURL){
      state.view="studentProfile";
    }
  }else{
    state.view="studentLogin";
  }
}

const esc=v=>String(v??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");const uid=()=>Math.random().toString(36).slice(2)+Date.now().toString(36);const classRef=(p="")=>database.ref(`classes/${CLASS_ID}${p?"/"+p:""}`);
function toast(msg,type="info",timeout=3200){const el=document.createElement("div");el.className=`toast ${type}`;el.innerHTML=`<span>${type==="success"?"✓":type==="warning"?"!":"•"}</span><div>${esc(msg)}</div>`;toastHost.appendChild(el);setTimeout(()=>{el.style.opacity="0";el.style.transform="translateY(8px)";setTimeout(()=>el.remove(),220)},timeout)}
function confetti(){const colors=["#ff8a00","#7c3aed","#22c55e","#facc15","#38bdf8"];for(let i=0;i<42;i++){let p=document.createElement("div");p.className="confetti-piece";p.style.left=Math.random()*100+"%";p.style.background=colors[i%colors.length];p.style.animationDelay=Math.random()*.25+"s";confettiHost.appendChild(p);setTimeout(()=>p.remove(),1900)}}
function requestFullScreenSoft(){if(!document.fullscreenElement&&document.documentElement.requestFullscreen)document.documentElement.requestFullscreen().catch(showFullscreenNudge)}function showFullscreenNudge(){let n=document.getElementById("fullscreenNudge");if(!n){n=document.createElement("div");n.id="fullscreenNudge";n.className="fullscreen-nudge";n.textContent="Press F to return to full screen.";document.body.appendChild(n)}n.classList.add("active");setTimeout(()=>n.classList.remove("active"),3500)}function toggleFS(){document.fullscreenElement?document.exitFullscreen?.():requestFullScreenSoft()}document.addEventListener("keydown",e=>{let tag=document.activeElement?.tagName?.toLowerCase(),typing=["input","textarea","select"].includes(tag);if(!typing&&e.key.toLowerCase()==="f"){e.preventDefault();toggleFS()}if(!typing&&state.view==="lecture"){if(e.key==="F9")markMoment("unclear");if(e.key==="F10")markMoment("connects")}});
function shell(content,brand=true){
  const roleLabel=state.lecturerAuth?"Lecturer dashboard":state.studentAuth?"Student dashboard":"Account";
  app.innerHTML=`<div class="app-shell"><div class="topbar">${brand?`<div class="brand-small"><div class="logo-mark">U</div><span>UnfoldED</span></div>`:`<div></div>`}<div class="nav-actions"><button class="btn btn-muted" id="helpBtn">Help</button><button class="btn btn-muted" id="fullscreenBtn">Full screen</button><div class="profile-wrap"><button class="btn btn-secondary profile-btn" id="profileBtn">Profile ▾</button><div class="profile-menu" id="profileMenu"><button type="button" id="roleDashboardBtn">${roleLabel}</button><button type="button" id="profileLogoutBtn">Log out</button></div></div></div></div>${content}</div>`;
  document.getElementById("helpBtn").onclick=()=>document.getElementById("helpModal")?.classList.add("active");
  document.getElementById("fullscreenBtn").onclick=toggleFS;
  let profileBtn=document.getElementById("profileBtn"),profileMenu=document.getElementById("profileMenu");
  profileBtn.onclick=e=>{e.stopPropagation();profileMenu.classList.toggle("active")};
  document.addEventListener("click",()=>profileMenu?.classList.remove("active"),{once:true});
  document.getElementById("roleDashboardBtn").onclick=()=>{state.view=state.lecturerAuth?"lecturer":state.studentAuth?"studentProfile":"studentLogin";if(state.lecturerAuth)listenForSubmissions();render()};
  document.getElementById("profileLogoutBtn").onclick=async()=>{await logoutStudent();state.view="studentLogin";render()};
}
function render(){let keepScroll=preserveNextScroll;let savedScrollX=window.scrollX||0;let savedScrollY=window.scrollY||0;preserveNextScroll=false;if(state.timerId){clearInterval(state.timerId);state.timerId=null}if(!state.studentAuth&&!state.lecturerAuth&&!["studentLogin","lecturerLogin"].includes(state.view))state.view="studentLogin";let map={studentStart:renderStudentStart,studentLogin:renderStudentLogin,lecture:renderLecture,review:renderReview,studentProfile:renderStudentProfile,lecturerLogin:renderLecturerLogin,lecturer:renderLecturerDashboard};(map[state.view]||renderStudentLogin)();renderHelpModal();saveAppState();setTimeout(()=>{try{if(keepScroll){window.scrollTo({top:savedScrollY,left:savedScrollX,behavior:"auto"})}else{window.scrollTo({top:0,left:0,behavior:"auto"})}}catch(e){window.scrollTo(savedScrollX,savedScrollY)}},0)}

function parseQuestionTime(value){let raw=String(value||"").trim();if(!raw)return 0;if(raw.includes(":")){let parts=raw.split(":").map(x=>parseInt(x,10));if(parts.some(Number.isNaN))return 0;if(parts.length===2)return Math.max(0,parts[0]*60+parts[1]);if(parts.length===3)return Math.max(0,parts[0]*3600+parts[1]*60+parts[2]);}let n=parseInt(raw,10);return Number.isFinite(n)?Math.max(0,n):0}
function questionTimeLabel(sec){sec=Math.max(0,Math.floor(Number(sec)||0));return formatTime(sec)}
function textFromQuestionValue(value){
  if(value==null)return "";
  if(typeof value==="string"){
    const trimmed=value.trim();
    return trimmed==="[object Object]"?"":trimmed;
  }
  if(typeof value==="object"){
    return textFromQuestionValue(value.question||value.text||value.prompt||value.label||value.value||"");
  }
  return String(value).trim();
}
function normalizeChoiceList(choices){
  let raw=Array.isArray(choices)?choices:(choices&&typeof choices==="object"?Object.values(choices):[]);
  let byLetter={};
  raw.forEach((c,i)=>{
    if(typeof c==="string")byLetter[String.fromCharCode(65+i)]={letter:String.fromCharCode(65+i),text:textFromQuestionValue(c)};
    else if(c&&typeof c==="object"){
      let letter=String(c.letter||String.fromCharCode(65+i)).toUpperCase().slice(0,1);
      byLetter[letter]={letter,text:textFromQuestionValue(c.text||c.answer||c.label||c.value)};
    }
  });
  return ["A","B","C","D"].map(letter=>byLetter[letter]||{letter,text:""}).filter(c=>c.text);
}
function normalizeQuestionObject(q){
  if(!q||typeof q!=="object")return null;
  let question=textFromQuestionValue(q.question||q.text||q.prompt);
  let choices=normalizeChoiceList(q.choices);
  if(!question||choices.length<2)return null;
  return {...q,question,choices,correct:String(q.correct||q.correctAnswer||"A").toUpperCase().slice(0,1),explanation:textFromQuestionValue(q.explanation||q.reason||""),time:Number(q.time)||0,id:q.id||uid()};
}
function buildQuestionForm(prefix,withTime=false){return `<div class="pause-question-form">${withTime?`<div><label for="${prefix}Time">Question time</label><input id="${prefix}Time" type="text" placeholder="Example: 02:30"></div>`:""}<div><label for="${prefix}Question">Question</label><input id="${prefix}Question" type="text" placeholder="Question students answer during the lecture"></div><div class="choice-grid"><input id="${prefix}A" type="text" placeholder="Option A"><input id="${prefix}B" type="text" placeholder="Option B"><input id="${prefix}C" type="text" placeholder="Option C"><input id="${prefix}D" type="text" placeholder="Option D"></div><div class="quiz-row"><div><label for="${prefix}Correct">Correct answer</label><select id="${prefix}Correct"><option value="A">Option A</option><option value="B">Option B</option><option value="C">Option C</option><option value="D">Option D</option></select></div><div><label for="${prefix}Explain">Explanation after answer</label><input id="${prefix}Explain" type="text" placeholder="Why this answer is correct"></div></div></div>`}
function readQuestionForm(prefix,withTime=false){let q=(document.getElementById(prefix+"Question")?.value||"").trim();let choices=["A","B","C","D"].map(letter=>({letter,text:(document.getElementById(prefix+letter)?.value||"").trim()}));let correct=document.getElementById(prefix+"Correct")?.value||"A";let explanation=(document.getElementById(prefix+"Explain")?.value||"").trim();let time=withTime?parseQuestionTime(document.getElementById(prefix+"Time")?.value):null;if(!q||choices.some(c=>!c.text)){toast("Please fill the question and all four answer choices.","warning");return null}return{id:uid(),time,question:q,choices,correct,explanation}}
function clearQuestionForm(prefix,withTime=false){["Question","A","B","C","D","Explain"].forEach(k=>{let el=document.getElementById(prefix+k);if(el)el.value=""});if(withTime){let t=document.getElementById(prefix+"Time");if(t)t.value=""}let c=document.getElementById(prefix+"Correct");if(c)c.value="A"}
function normalizeRecordedQuestions(v){let arr=[];if(Array.isArray(v))arr=v;else if(v&&typeof v==="object")arr=Object.values(v);return arr.map(normalizeQuestionObject).filter(Boolean).sort((a,b)=>(a.time||0)-(b.time||0))}
async function loadRecordedQuestionsOnce(){try{let snap=await classRef("recordedQuestions").get();state.recordedPauseQuestions=normalizeRecordedQuestions(snap.val());return state.recordedPauseQuestions}catch(e){console.error("Recorded questions did not load from Firebase",e);toast("Recorded questions could not load from Firebase.","warning");return state.recordedPauseQuestions||[]}}
async function saveRecordedQuestionsToFirebase(message="Timed recorded questions saved to Firebase."){await classRef("recordedQuestions").set(state.recordedPauseQuestions||[]);toast(message,"success")}
function normalizeQuestionnaire(v){let arr=Array.isArray(v)?v:(v&&typeof v==="object"?Object.values(v):[]);return arr.map(textFromQuestionValue).filter(Boolean).slice(0,5)}
async function loadRecordedQuestionnaireOnce(){try{let snap=await classRef("recordedQuestionnaire").get();state.recordedQuestionnaire=normalizeQuestionnaire(snap.val());let en=await classRef("recordedQuestionnaireEnabled").get();state.recordedQuestionnaireEnabled=en.val()!==false;return state.recordedQuestionnaire}catch(e){console.error("Recorded questionnaire did not load",e);return state.recordedQuestionnaire||[]}}
async function saveRecordedQuestionnaire(){let qs=[...document.querySelectorAll(".recordedQuestionnaireInput")].map(i=>textFromQuestionValue(i.value)).filter(Boolean).slice(0,5);state.recordedQuestionnaire=qs;state.recordedQuestionnaireEnabled=document.getElementById("enableRecordedQuestionnaire")?.checked!==false;await classRef("recordedQuestionnaire").set(qs);await classRef("recordedQuestionnaireEnabled").set(state.recordedQuestionnaireEnabled);toast("Recorded lecture questionnaire sent to students.","success");render()}
function renderLiveQuestionPanel(){return `<div class="question-card compact-question-card"><h4>Live lecture question</h4><p>Use these with the A/B/C/D along with the fidget toy from the board. Students move the fidget toy first, then click the right answer digitally.</p>${buildQuestionForm("liveQ",false)}<div class="btn-row"><button class="btn btn-primary" id="sendLiveQuestionBtn">Send Live Question</button><button class="btn btn-muted" id="clearLiveQuestionBtn">Clear Live Question</button></div></div>`}
function renderRecordedLectureControl(){return `<section class="card recorded-control"><div class="dashboard-header"><div><h3>Recorded Lecture Control</h3><p>Create timed questions and review questions for recorded lectures.</p></div></div><div class="recorded-control-grid"><div class="question-card compact-question-card"><h4>Recorded lecture timed question</h4><p>Use these with the A/B/C/D along with the fidget toy from the board. Students move the fidget toy first, then click the right answer digitally.</p>${buildQuestionForm("recordedQ",true)}<div class="btn-row"><button class="btn btn-primary" id="addRecordedQuestionBtn">Save Timed Question</button></div><div class="saved-questions">${state.recordedPauseQuestions.length?state.recordedPauseQuestions.map((q,i)=>`<div class="saved-question"><strong>${questionTimeLabel(q.time)} · ${esc(q.question)}</strong><span>Correct: ${esc(q.correct)}</span><button class="mini-delete" type="button" data-qindex="${i}">Remove</button></div>`).join(""):`<div class="empty-small">No timed questions yet.</div>`}</div></div><div class="question-card recorded-questionnaire-card compact-question-card"><div class="dashboard-header small-header"><div><h4>Recorded post-lecture questionnaire</h4><p>These questions appear on student's review after a student finished a recorded lecture.</p></div></div><label class="checkline"><input type="checkbox" id="enableRecordedQuestionnaire" ${state.recordedQuestionnaireEnabled!==false?"checked":""}>Send recorded post-lecture questionnaire</label><div class="question-list">${[0,1,2,3,4].map(i=>`<input type="text" class="recordedQuestionnaireInput" value="${esc(textFromQuestionValue((state.recordedQuestionnaire||[])[i]||""))}" placeholder="Recorded question ${i+1}">`).join("")}</div><div class="btn-row"><button class="btn btn-secondary" id="saveRecordedQuestionnaireBtn">Send Recorded Questionnaire</button></div></div></div></section>`}
function renderPauseQuestionPanel(){return `<section class="card pause-question-panel"><div class="dashboard-header"><div><h3>Pause & Reflect Questions</h3></div></div><div class="pause-question-grid">${renderLiveQuestionPanel()}${renderRecordedLectureControl()}</div></section>`}
function renderPauseQuestionPanel(){return `<section class="card pause-question-panel"><div class="dashboard-header"><div><h3>Pause & Reflect Questions</h3><p>Use these with the A/B/C/D analog puck board. Students move the puck first, then click the same answer online.</p></div></div><div class="pause-question-grid"><div class="question-card"><h4>Live lecture question</h4><p>Send a question during a live lecture whenever you want to check understanding.</p>${buildQuestionForm("liveQ",false)}<div class="btn-row"><button class="btn btn-primary" id="sendLiveQuestionBtn">Send Live Question</button><button class="btn btn-muted" id="clearLiveQuestionBtn">Clear Live Question</button></div></div><div class="question-card"><h4>Recorded lecture timed question</h4><p>Add a question that pauses the video at a specific time, like a course check-in.</p>${buildQuestionForm("recordedQ",true)}<div class="btn-row"><button class="btn btn-primary" id="addRecordedQuestionBtn">Add Timed Question</button><button class="btn btn-secondary" id="saveRecordedQuestionsBtn">Save Questions</button></div><div class="saved-questions">${state.recordedPauseQuestions.length?state.recordedPauseQuestions.map((q,i)=>`<div class="saved-question"><strong>${questionTimeLabel(q.time)} · ${esc(q.question)}</strong><span>Correct: ${esc(q.correct)}</span><button class="mini-delete" type="button" data-qindex="${i}">Remove</button></div>`).join(""):`<div class="empty-small">No timed questions yet.</div>`}</div></div><div class="question-card recorded-questionnaire-card"><h4>Recorded post-lecture questionnaire</h4><p>These questions appear after any student finishes reviewing a recorded lecture.</p><div class="question-list">${[0,1,2,3,4].map(i=>`<input type="text" class="recordedQuestionnaireInput" value="${esc(textFromQuestionValue((state.recordedQuestionnaire||[])[i]||""))}" placeholder="Recorded question ${i+1}">`).join("")}</div><div class="btn-row"><button class="btn btn-secondary" id="saveRecordedQuestionnaireBtn">Save Recorded Questionnaire</button></div></div></div></section>`}
async function sendLiveQuestion(){let q=readQuestionForm("liveQ",false);if(!q)return;await classRef("activeLecture/liveQuestion").set({...q,sentAt:Date.now()});toast("Live question sent to students.","success");clearQuestionForm("liveQ",false)}
async function clearLiveQuestion(){await classRef("activeLecture/liveQuestion").remove();toast("Live question cleared.","success")}
async function addRecordedQuestion(){let q=readQuestionForm("recordedQ",true);if(!q)return;state.recordedPauseQuestions=[...(state.recordedPauseQuestions||[]),q].sort((a,b)=>a.time-b.time);await saveRecordedQuestionsToFirebase("Timed question added and saved to Firebase.");clearQuestionForm("recordedQ",true);render()}
async function saveRecordedQuestions(){await saveRecordedQuestionsToFirebase("All timed questions saved to Firebase.");await loadRecordedQuestionsOnce();render()}
async function removeRecordedQuestion(index){state.recordedPauseQuestions=(state.recordedPauseQuestions||[]).filter((_,i)=>i!==index);await saveRecordedQuestionsToFirebase("Timed question removed from Firebase.");render()}
function maybeTriggerRecordedQuestion(media){if(!media||state.sessionMode!=="recorded")return;let now=media.currentTime||0;let q=state.recordedPauseQuestions.find(x=>now>=x.time && !state.pauseAnswers[x.id]);if(q){media.pause();showPauseQuestion(q,"recorded")}}
function maybeShowLiveQuestion(){let q=normalizeQuestionObject(state.activeLecture?.liveQuestion);if(state.sessionMode==="live"&&state.joinedLive&&state.view==="lecture"&&q&&!state.pauseAnswers[q.id])showPauseQuestion(q,"live")}
function showPauseQuestion(q,source){
  q=normalizeQuestionObject(q);
  if(!q)return;
  if(document.getElementById("pauseQuestionModal"))return;
  let selectedAnswer=null;
  let modal=document.createElement("div");
  modal.id="pauseQuestionModal";
  modal.className="pause-question-modal active";
  modal.innerHTML=`<div class="pause-question-card"><div class="pause-question-head"><div><span class="status-pill status-live">Pause & Reflect</span><h3>${esc(q.question)}</h3><p>Move your puck to the matching A/B/C/D location first. Choose an answer here, then submit when you are sure.</p></div></div><div class="answer-grid">${q.choices.map(c=>`<button class="answer-choice" type="button" data-answer="${c.letter}"><strong>${c.letter}</strong><span>${esc(c.text)}</span></button>`).join("")}</div><div id="questionFeedback" class="question-feedback" aria-live="polite"></div><div class="btn-row"><button class="btn btn-primary" id="submitQuestionBtn" disabled>Submit Answer</button><button class="btn btn-muted" id="continueQuestionBtn" disabled>Continue</button></div></div>`;
  document.body.appendChild(modal);
  modal.querySelectorAll(".answer-choice").forEach(btn=>{
    btn.onclick=()=>{
      selectedAnswer=btn.dataset.answer;
      modal.querySelectorAll(".answer-choice").forEach(b=>b.classList.remove("answer-selected"));
      btn.classList.add("answer-selected");
      document.getElementById("submitQuestionBtn").disabled=false;
    };
  });
  document.getElementById("submitQuestionBtn").onclick=()=>{
    if(!selectedAnswer)return;
    let correct=selectedAnswer===q.correct;
    state.pauseAnswers[q.id]={question:q.question,selected:selectedAnswer,correctAnswer:q.correct,correct,explanation:q.explanation||"",time:q.time??currentSeconds(),source};
    modal.querySelectorAll(".answer-choice").forEach(b=>{
      b.disabled=true;
      let ans=b.dataset.answer;
      if(ans===q.correct)b.classList.add("answer-right");
      if(ans===selectedAnswer&&ans!==q.correct)b.classList.add("answer-wrong");
    });
    let fb=document.getElementById("questionFeedback");
    fb.className=`question-feedback ${correct?"right":"wrong"}`;
    fb.innerHTML=correct?`<strong>Correct.</strong> ${esc(q.explanation||"You can continue.")}`:`<strong>Not quite.</strong> Correct answer: ${esc(q.correct)}. ${esc(q.explanation||"")}`;
    document.getElementById("submitQuestionBtn").style.display="none";
    document.getElementById("continueQuestionBtn").disabled=false;
  };
  document.getElementById("continueQuestionBtn").onclick=()=>{
    modal.remove();
    let media=document.getElementById("lectureMedia");
    if(source==="recorded"&&media)media.play().catch(()=>{});
  };
}
function statusClass(s){return s==="live"?"status-live":s==="ready"?"status-ready":s==="ended"?"status-ended":"status-none"}
function statusLabel(s){return s==="live"?"Lecture started":s==="ready"?"Lecture prepared":s==="ended"?"Lecture ended":"No lecture"}
function liveStatus(){if(!state.activeLecture)return{label:"Lecture has not started",cls:"status-none",desc:"No live lecture is available yet. Please wait for the lecturer to prepare a session."};if(state.activeLecture.status==="ready")return{label:"Lecture has not started",cls:"status-ready",desc:state.activeLecture.title||"A live lecture is prepared. You can join and wait for the lecturer to start."};if(state.activeLecture.status==="live")return{label:"Lecture started",cls:"status-live",desc:state.activeLecture.title||"The live lecture is currently running."};return{label:"Lecture ended",cls:"status-ended",desc:"This live lecture has ended. Please wait for the lecturer to prepare a new session."}}


const userRef=uid=>database.ref(`users/${uid}`);
const studentRef=(uid,path="")=>database.ref(`students/${uid}${path?"/"+path:""}`);
const usernameKey=name=>String(name||"").trim().toLowerCase().replace(/[^a-z0-9_-]/g,"");
const usernameRef=username=>database.ref(`usernames/${usernameKey(username)}`);
function currentFirebaseUser(){return auth.currentUser}
function authDisplayName(profile,user){return profile?.displayName||user?.displayName||user?.email?.split("@")[0]||"Student"}
async function loadFirebaseUserProfile(user){
  if(!user){state.studentAuth=null;state.lecturerAuth=null;state.studentSavedSessions={};return null}
  let snap=await userRef(user.uid).get();
  let profile=snap.val();
  if(!profile){profile={email:user.email||"",displayName:authDisplayName(null,user),role:"student",createdAt:Date.now()};await userRef(user.uid).set(profile)}
  if(profile.role==="lecturer"){
    state.lecturerAuth={uid:user.uid,email:user.email,displayName:authDisplayName(profile,user),username:profile?.username||"",role:"lecturer"};
    state.studentAuth=null;
  }else{
    state.studentAuth={uid:user.uid,email:user.email,displayName:authDisplayName(profile,user),username:profile?.username||"",role:"student"};
    state.lecturerAuth=null;
    state.name=state.studentAuth.displayName;
    let sessions=await studentRef(user.uid,"sessions").get();
    state.studentSavedSessions=sessions.val()||{};
  }
  return profile;
}
async function createAccount(email,password,displayName,role,username){
  email=String(email||"").trim();password=String(password||"");displayName=String(displayName||"").trim()||email.split("@")[0];role=role||"student";username=usernameKey(username||displayName);
  if(!displayName||!username||!email||!password)return toast("Please enter name, username, email, and password.","warning"),false;
  if(!/^[a-z0-9_-]{3,24}$/.test(username))return toast("Username must be 3–24 letters, numbers, underscores, or dashes.","warning"),false;
  if(password.length<6)return toast("Firebase requires passwords to be at least 6 characters.","warning"),false;
  let usernameSnap=await usernameRef(username).get();
  if(usernameSnap.exists())return toast("That username is already taken. Try another username.","warning"),false;
  let cred=await auth.createUserWithEmailAndPassword(email,password);
  await cred.user.updateProfile({displayName});
  await userRef(cred.user.uid).set({email,displayName,username,role,createdAt:Date.now(),updatedAt:Date.now()});
  await usernameRef(username).set({uid:cred.user.uid,email,role,displayName,createdAt:Date.now()});
  if(role==="student")await studentRef(cred.user.uid,"profile").set({displayName,username,email,createdAt:Date.now()});
  await loadFirebaseUserProfile(cred.user);
  return true;
}
async function loginAccount(username,password){
  username=String(username||"").trim();password=String(password||"");
  if(!username||!password)return toast("Please enter your username and password.","warning"),false;
  let loginValue=username;
  let email="";
  if(loginValue.includes("@")) email=loginValue;
  else{
    let snap=await usernameRef(loginValue).get();
    if(!snap.exists())return toast("Username not found. Check your username or create an account.","warning"),false;
    email=snap.val()?.email||"";
  }
  let cred=await auth.signInWithEmailAndPassword(email,password);
  await loadFirebaseUserProfile(cred.user);
  return true;
}
async function logoutStudent(){await auth.signOut();state.studentAuth=null;state.lecturerAuth=null;state.studentSavedSessions={};state.joinedLive=false;clearAppState();toast("Logged out.","info")}
async function loadSavedStudent(){return new Promise(resolve=>{auth.onAuthStateChanged(async user=>{try{await loadFirebaseUserProfile(user)}catch(e){console.error(e);toast("Account data could not load.","warning")}resolve(user)},e=>resolve(null))})}
function ensureSessionRun(){if(!state.sessionRunId)state.sessionRunId="session-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,8);return state.sessionRunId}
function resetLearningSession(){state.sessionRunId="session-"+Date.now().toString(36)+"-"+Math.random().toString(36).slice(2,8);state.markers=[];state.reflections={};state.shareSettings={};state.questionnaireAnswers={};state.noteFiles=[];state.pauseAnswers={};state.replayedMarkers={};state.submitted=false}
function sessionProgressSnapshot(){return{title:state.sessionTitle||state.activeLecture?.title||"Untitled session",updatedAt:Date.now(),markers:state.markers.length,unclear:countType("unclear"),connects:countType("connects"),notes:(state.noteFiles||[]).length,replayed:Object.keys(state.replayedMarkers||{}).length,reflected:hasAnyReflection()?1:0,recalled:hasAnyQuestionAnswer()?1:0,submitted:state.submitted?1:0}}
function saveStudentProgress(){if(!state.studentAuth||!state.studentAuth.uid)return;let sid=ensureSessionRun(),snap=sessionProgressSnapshot();state.studentSavedSessions={...(state.studentSavedSessions||{}),[sid]:snap};studentRef(state.studentAuth.uid,"sessions/"+sid).set(snap).catch(e=>console.error("Student progress save failed",e))}
function currentStudentProgress(){let sessionOnly={markers:state.markers.length,unclear:countType("unclear"),connects:countType("connects"),notes:(state.noteFiles||[]).length,replayed:Object.keys(state.replayedMarkers||{}).length,reflected:hasAnyReflection()?1:0,recalled:hasAnyQuestionAnswer()?1:0,submitted:state.submitted?1:0};if(!state.studentAuth)return sessionOnly;saveStudentProgress();let sessions=Object.values(state.studentSavedSessions||{});return sessions.reduce((sum,x)=>{sum.markers+=(x.markers||0);sum.unclear+=(x.unclear||0);sum.connects+=(x.connects||0);sum.notes+=(x.notes||0);sum.replayed+=(x.replayed||0);sum.reflected=Math.max(sum.reflected,x.reflected||0);sum.recalled=Math.max(sum.recalled,x.recalled||0);sum.submitted=Math.max(sum.submitted,x.submitted||0);return sum},{markers:0,unclear:0,connects:0,notes:0,replayed:0,reflected:0,recalled:0,submitted:0})}
function renderStudentLogin(){renderAuthPage("student")}
function renderAuthPage(defaultRole="student"){
  app.innerHTML=`<div class="app-shell auth-shell"><section class="auth-hero"><h1>UnfoldED</h1><p>Mark your moments. Unfold the understanding.</p></section><div class="auth-layout"><section class="card auth-card auth-card-wide"><h2>Log in or create an account</h2><p>Create an account or log in to continue to your saved dashboard.</p><div class="auth-two-col"><div class="auth-panel"><h3>Log in</h3><div class="form-stack"><label for="loginUsername">Username</label><input id="loginUsername" type="text" placeholder="Username" autocomplete="off"><label for="loginPass">Password</label><input id="loginPass" type="password" placeholder="Password" autocomplete="current-password"></div><div class="btn-row"><button class="btn btn-primary" id="authLoginBtn">Log in</button></div></div><div class="auth-panel create-panel"><h3>Create account</h3><div class="form-stack"><label for="authName">Name</label><input id="authName" type="text" placeholder="Name" autocomplete="off"><label for="authUsername">Username</label><input id="authUsername" type="text" placeholder="Username" autocomplete="off"><label for="authEmail">Email</label><input id="authEmail" type="email" placeholder="Name@gmail.com" autocomplete="off"><label for="authPass">Password</label><input id="authPass" type="password" placeholder="At least 6 characters" autocomplete="new-password"><label for="authRole">Account type</label><select id="authRole"><option value="student" ${defaultRole==="student"?"selected":""}>Student</option><option value="lecturer" ${defaultRole==="lecturer"?"selected":""}>Lecturer</option></select></div><div class="btn-row"><button class="btn btn-secondary" id="authCreateBtn">Create account</button></div></div></div></section></div></div>`;
  let loginUsername=()=>document.getElementById("loginUsername").value, loginPass=()=>document.getElementById("loginPass").value;
  let email=()=>document.getElementById("authEmail").value, pass=()=>document.getElementById("authPass").value, name=()=>document.getElementById("authName").value, username=()=>document.getElementById("authUsername").value, role=()=>document.getElementById("authRole").value;
  async function go(){if(state.lecturerAuth){listenForSubmissions();state.view="lecturer"}else state.view="studentProfile";render()}
  document.getElementById("authLoginBtn").onclick=async()=>{try{if(await loginAccount(loginUsername(),loginPass())){toast("Logged in.","success");await go()}}catch(e){toast(authError(e),"warning",5000);console.error(e)}};
  document.getElementById("authCreateBtn").onclick=async()=>{try{if(await createAccount(email(),pass(),name(),role(),username())){toast("Account created.","success");await go()}}catch(e){toast(authError(e),"warning",5000);console.error(e)}};
}
function authError(e){let c=e?.code||"";if(c.includes("email-already"))return"That email already has an account. Try logging in.";if(c.includes("invalid-email"))return"Please enter a valid email.";if(c.includes("wrong-password")||c.includes("invalid-credential"))return"Incorrect email or password.";if(c.includes("weak-password"))return"Password must be at least 6 characters.";return e?.message||"Authentication failed."}

function hasAnyReflection(){return Object.values(state.reflections||{}).some(v=>String(v||"").trim().length>0)}
function hasAnyQuestionAnswer(){return Object.values(state.questionnaireAnswers||{}).some(v=>String(v||"").trim().length>0)||Object.values(state.pauseAnswers||{}).some(v=>v&&String(v.answer||v.selected||v).trim().length>0)}
function getStudentBadges(){
  const p=currentStudentProgress();
  return [
    {key:"moment",icon:"✦",title:"Moment Marker",desc:"Marked a learning moment during lecture.",unlocked:p.markers>0},
    {key:"unclear",icon:"?",title:"Confusion Tracker",desc:"Captured a moment that felt unclear.",unlocked:p.unclear>0},
    {key:"connect",icon:"↔",title:"Connection Maker",desc:"Marked a connection to another idea or experience.",unlocked:p.connects>0},
    {key:"notes",icon:"✎",title:"Note Connector",desc:"Attached handwritten notes to the review.",unlocked:p.notes>0},
    {key:"replay",icon:"↺",title:"Replay Returner",desc:"Replayed a marked moment instead of guessing later.",unlocked:p.replayed>0},
    {key:"reflect",icon:"☁",title:"Reflective Thinker",desc:"Wrote a reflection about what happened during a marker.",unlocked:p.reflected>0},
    {key:"recall",icon:"✓",title:"Active Recall",desc:"Answered a mid-lecture or post-lecture question.",unlocked:p.recalled>0},
    {key:"builder",icon:"★",title:"Understanding Builder",desc:"Completed a full loop: mark, notes, replay, and reflect.",unlocked:p.markers>0&&p.notes>0&&p.replayed>0&&p.reflected>0},
    {key:"submit",icon:"→",title:"Learning Trace Submitted",desc:"Submitted reflections for review or follow-up.",unlocked:p.submitted>0}
  ];
}
function renderBadgeCard(b){return `<div class="badge-card ${b.unlocked?"unlocked":"locked"}"><div class="badge-icon">${esc(b.icon)}</div><div><strong>${esc(b.title)}</strong><p>${esc(b.desc)}</p><span>${b.unlocked?"Unlocked":"Keep going"}</span></div></div>`}
function studentDashboardName(){let n=state.studentAuth?.displayName||state.name||"Student";return `${n}'s Dashboard`}
function studentHomeHTML(){let ls=liveStatus();return `<section class="student-home-block"><div class="student-instructions card"><h3>How UnfoldED works</h3><p>First, start the lecture. Then connect the UnfoldED physical buttons. Take handwritten notes while listening to a live or recorded lecture. Use the UnfoldED physical buttons to press <strong>Unclear</strong> when a concept feels confusing, incomplete, or needs another example. Press <strong>Connects</strong> when a concept connects to prior knowledge, another class, or a personal experience. Write the matching code in your notebook, such as <strong>U1</strong> or <strong>C1</strong>, then unfold the moment during review. Use the <strong>Help</strong> button for more explanation.</p></div><section class="grid-start dashboard-start"><div class="card mode-card"><h3>Join Live Lecture</h3><div class="live-status-row"><span class="status-pill ${ls.cls}">${ls.label}</span></div>${state.activeLecture&&state.activeLecture.title?`<p class="live-session-title"><strong>Session title:</strong> ${esc(state.activeLecture.title)}</p>`:`<p>${esc(ls.desc)}</p>`}<div class="form-stack"><label>Name</label><input type="text" value="${esc(state.studentAuth?.displayName||state.name||"Student")}" readonly></div><div class="btn-row"><button class="btn btn-primary" id="joinLiveBtn" ${!state.activeLecture||state.activeLecture.status==="ended"?"disabled":""}>Join Live Lecture</button></div></div><div class="card mode-card"><h3>Start Recorded Lecture</h3><p>Use this when you are reviewing a lecture recording independently.</p><div class="form-stack"><label for="recordedTitle">Session title</label><input id="recordedTitle" type="text" placeholder="Title" value="${esc(["Untitled Live Lecture","Live Lecture","Untitled Lecture"].includes(state.sessionTitle)?"":state.sessionTitle)}"><label>Name</label><input type="text" value="${esc(state.studentAuth?.displayName||state.name||"Student")}" readonly><label for="recordedFile">Lecture recording</label><div class="file-box"><input id="recordedFile" type="file" accept="video/*,audio/*"></div></div><div class="btn-row"><button class="btn btn-primary" id="startRecordedBtn">Start with recording</button></div></div><div class="card preview-card"><div class="preview-visual"><div class="marker-bubble unclear">U1</div><div class="marker-bubble connects">C1</div></div><p>Write the matching code in your notebook, then unfold the moment during review.</p></div></section></section>`}
function attachStudentHomeHandlers(){let title=document.getElementById("recordedTitle"),file=document.getElementById("recordedFile"),join=document.getElementById("joinLiveBtn"),startBtn=document.getElementById("startRecordedBtn");if(title)title.oninput=e=>state.sessionTitle=e.target.value;if(file)file.onchange=e=>{state.lectureFile=e.target.files?.[0]||null};if(join)join.onclick=()=>{state.name=state.studentAuth?.displayName||"Student";state.sessionMode="live";state.sessionTitle=state.activeLecture?.title||"Live Lecture";state.joinedLive=true;resetLearningSession();state.currentStartedAt=state.activeLecture?.startedAt||null;state.view="lecture";render()};if(startBtn)startBtn.onclick=async()=>{let t=document.getElementById("recordedTitle")?.value.trim(),name=state.studentAuth?.displayName||"Student";if(!t)return toast("Please enter a session title.","warning");if(!state.lectureFile)return toast("Please choose a lecture recording first.","warning");await loadRecordedQuestionsOnce();await loadRecordedQuestionnaireOnce();state.sessionMode="recorded";state.sessionTitle=t;state.name=name;state.lectureURL=URL.createObjectURL(state.lectureFile);resetLearningSession();state.currentStartedAt=Date.now();state.view="lecture";render()}}
function renderStudentProfile(){
  if(!state.studentAuth){state.view="studentLogin";return renderStudentLogin()}
  state.name=state.studentAuth.displayName||state.name||"Student";
  const p=currentStudentProgress();
  const badges=getStudentBadges(),unlocked=badges.filter(b=>b.unlocked).length,total=badges.length,percent=Math.round(unlocked/total*100);
  shell(`<section class="profile-page student-dashboard"><div class="profile-hero card"><div><h2>${esc(studentDashboardName())}</h2><p>Start a lecture, review learning moments, and track your progress.</p></div><div class="profile-score"><strong>${unlocked}/${total}</strong><span>badges unlocked</span></div></div>${studentHomeHTML()}<section class="card progress-card"><div class="progress-head"><div><h3>Learning progress</h3></div><strong>${percent}%</strong></div><div class="progress-track"><div class="progress-fill" style="width:${percent}%"></div></div><div class="profile-stats"><div><strong>${p.markers}</strong><span>Moments marked</span></div><div><strong>${p.notes}</strong><span>Notes attached</span></div><div><strong>${p.replayed}</strong><span>Moments replayed</span></div><div><strong>${p.recalled>0?"Yes":"Not yet"}</strong><span>Recall checked</span></div></div></section><section><div class="section-title-row"><h3>Student badges <span class="badge-count-inline">${unlocked}/${total} unlocked</span></h3></div><div class="badge-grid">${badges.map(renderBadgeCard).join("")}</div></section><div class="dashboard-actions"><button class="btn btn-muted" id="studentLogoutBtn">Log out</button></div></section>`);
  attachStudentHomeHandlers();
  document.getElementById("studentLogoutBtn").onclick=()=>{logoutStudent();state.view="studentLogin";render()};
}
function renderStudentStart(){if(!state.studentAuth){state.view="studentLogin";return renderStudentLogin()}state.view="studentProfile";return renderStudentProfile()}


// Arduino Uno Web Serial support.
// Arduino sends one line at a time: UNCLEAR or CONNECT.
let arduinoPort=null;
let arduinoReader=null;
let arduinoConnected=false;
let arduinoReading=false;

function setArduinoStatus(message, ok=false){
  const el=document.getElementById("arduinoStatus");
  if(el){
    el.textContent=message;
    el.classList.toggle("status-ok", !!ok);
  }

  // Hide the onboarding warning once the physical buttons are connected.
  // Keep it visible only when the student still needs to connect the Arduino/USB port.
  const alert=document.getElementById("arduinoConnectionAlert");
  if(alert){
    alert.style.display = ok ? "none" : "grid";
    alert.setAttribute("aria-hidden", ok ? "true" : "false");
  }
}

function refreshArduinoStatus(){
  if(!document.getElementById("arduinoStatus"))return;
  if(!("serial" in navigator)){
    setArduinoStatus("Web Serial is not available. Use Chrome or Edge on localhost or HTTPS.", false);
  }else if(arduinoConnected){
    setArduinoStatus("UnfoldED Physical buttons connected.", true);
  }else{
    setArduinoStatus("UnfoldED Physical buttons not connected.", false);
  }
}

async function connectArduinoButtons(){
  if(!("serial" in navigator)){
    toast("Web Serial is not available. Open this app in Chrome or Edge using localhost or HTTPS.", "warning", 5000);
    refreshArduinoStatus();
    return;
  }
  try{
    if(!arduinoPort){
      arduinoPort=await navigator.serial.requestPort();
    }
    if(!arduinoPort.readable){
      await arduinoPort.open({baudRate:9600});
    }
    arduinoConnected=true;
    refreshArduinoStatus();
    toast("UnfoldED Physical buttons connected.", "success");
    if(!arduinoReading) readArduinoLoop();
  }catch(err){
    console.error("Arduino connection failed", err);
    arduinoConnected=false;
    setArduinoStatus("Physical button connection failed. Check cable, port, browser, and localhost/HTTPS.", false);
    toast("Physical button connection failed. Try Chrome/Edge and select the Arduino/USB port.", "warning", 6000);
  }
}

async function readArduinoLoop(){
  if(!arduinoPort || !arduinoPort.readable)return;
  arduinoReading=true;
  const decoder=new TextDecoderStream();
  let closedPromise=arduinoPort.readable.pipeTo(decoder.writable).catch(()=>{});
  arduinoReader=decoder.readable.getReader();
  let buffer="";
  try{
    while(true){
      const {value,done}=await arduinoReader.read();
      if(done)break;
      if(!value)continue;
      buffer+=value;
      const lines=buffer.split(/\r?\n/);
      buffer=lines.pop()||"";
      for(const raw of lines){
        handleArduinoCommand(raw.trim());
      }
    }
  }catch(err){
    console.error("Arduino read error", err);
  }finally{
    try{arduinoReader.releaseLock()}catch(e){}
    await closedPromise;
    arduinoReading=false;
    arduinoConnected=false;
    refreshArduinoStatus();
  }
}

function handleArduinoCommand(command){
  if(!command)return;
  console.log("Arduino:", command);
  const cmd=command.toUpperCase();
  if(state.view!=="lecture"){
    toast("Arduino input received, but you are not on the lecture screen.", "info", 2500);
    return;
  }
  if(cmd==="UNCLEAR" || cmd==="U"){
    markMoment("unclear");
    flashPhysicalCounter("unclear");
  }else if(cmd==="CONNECT" || cmd==="CONNECTS" || cmd==="C"){
    markMoment("connects");
    flashPhysicalCounter("connects");
  }else{
    console.warn("Unknown Arduino command:", command);
  }
}

function flashPhysicalButton(id){
  const btn=document.getElementById(id);
  if(!btn)return;
  btn.classList.add("arduino-flash");
  setTimeout(()=>btn.classList.remove("arduino-flash"),350);
}

function flashPhysicalCounter(type){
  const card=document.querySelector(`.count-card.${type === "unclear" ? "unclear" : "connects"}`);
  if(!card)return;
  card.classList.add("arduino-flash");
  setTimeout(()=>card.classList.remove("arduino-flash"),350);
}

function formatTime(t){t=Math.max(0,Math.floor(t));return `${String(Math.floor(t/60)).padStart(2,"0")}:${String(t%60).padStart(2,"0")}`}function countType(type){return state.markers.filter(m=>m.type===type).length}function currentSeconds(){if(state.sessionMode==="recorded"){let m=document.getElementById("lectureMedia");return m?Math.floor(m.currentTime):Math.floor((Date.now()-(state.currentStartedAt||Date.now()))/1000)}if(state.activeLecture&&state.activeLecture.status!=="live"&&state.activeLecture.status!=="ended")return 0;let start=state.activeLecture?.startedAt||state.currentStartedAt;if(!start)return 0;let end=state.activeLecture?.status==="ended"?(state.activeLecture.endedAt||Date.now()):Date.now();return Math.max(0,Math.floor((end-start)/1000))}
function renderLecture(){let live=state.sessionMode==="live",ended=live&&state.activeLecture?.status==="ended",reviewDisabled=live&&!ended;let liveNote=live?`<div class="note-box">Live lecture start and end are controlled by the lecturer.</div>`:"";let connectionNotice=arduinoConnected?"":`<div class="arduino-alert" id="arduinoConnectionAlert" role="status" aria-live="polite"><strong>Connect physical buttons first</strong><p>Before marking Unclear or Connects, click the button below and select the Arduino/USB port.</p></div>`;shell(`<section class="review-layout"><div class="lecture-head-row"><div><h2>${esc(state.sessionTitle||"Untitled Live Lecture")}</h2><p>Student: ${esc(state.name||"Anonymous")}</p><p>Mode: ${live?"Live lecture":"Recorded lecture"}</p></div><button class="btn btn-muted" id="backToDashboardLectureBtn" type="button">Back to Dashboard</button></div><div class="student-layout"><div class="lecture-stage">${live?`<div class="stage-empty"><h3>${state.activeLecture?.status==="live"?"Live lecture mode":state.activeLecture?.status==="ended"?"Live lecture ended":"Waiting for lecturer"}</h3><p>${state.activeLecture?.status==="live"?"":state.activeLecture?.status==="ended"?"You can now review the moments you marked.":"Please wait for the lecturer to start the live lecture."}</p></div>`:(state.lectureFile?.type?.startsWith("audio/")?`<audio id="lectureMedia" controls src="${state.lectureURL}"></audio>`:`<video id="lectureMedia" controls src="${state.lectureURL}"></video>`)}</div><aside class="side-panel"><div class="timer-card"><strong>Current lecture time</strong><div class="time" id="timeDisplay">00:00</div></div><div class="count-grid"><div class="count-card unclear"><strong id="unclearCount">${countType("unclear")}</strong>Unclear</div><div class="count-card connects"><strong id="connectsCount">${countType("connects")}</strong>Connects</div></div>${liveNote}${connectionNotice}<div class="test-box arduino-only-box"><strong>UnfoldED Physical Buttons</strong><p class="small-muted">Connect the physical buttons to begin marking Unclear and Connects moments.</p><div class="arduino-box"><button class="btn btn-primary btn-full arduino-connect-cta" id="connectArduinoBtn" type="button">Connect Physical Buttons</button><p class="small-muted" id="arduinoStatus">UnfoldED Physical buttons not connected.</p></div></div><button class="btn btn-primary btn-full" id="reviewNowBtn" ${reviewDisabled?"disabled":""}>Review Now</button></aside></div></section>`);let backBtn=document.getElementById("backToDashboardLectureBtn");if(backBtn)backBtn.onclick=()=>{state.view=state.studentAuth?"studentProfile":"studentStart";render()};let arduinoBtn=document.getElementById("connectArduinoBtn");if(arduinoBtn)arduinoBtn.onclick=connectArduinoButtons;refreshArduinoStatus();document.getElementById("reviewNowBtn").onclick=()=>{if(reviewDisabled)return toast("Review opens after the lecturer ends the live lecture.","info");state.view="review";render()};let media=document.getElementById("lectureMedia");if(media){media.onplay=()=>{if(!state.currentStartedAt)state.currentStartedAt=Date.now()-media.currentTime*1000};media.ontimeupdate=()=>maybeTriggerRecordedQuestion(media)}maybeShowLiveQuestion();state.timerId=setInterval(()=>{updateLectureUI();if(media)maybeTriggerRecordedQuestion(media);maybeShowLiveQuestion()},300);updateLectureUI()}
function updateLectureUI(){let t=document.getElementById("timeDisplay");if(t)t.textContent=formatTime(currentSeconds());let u=document.getElementById("unclearCount"),c=document.getElementById("connectsCount");if(u)u.textContent=countType("unclear");if(c)c.textContent=countType("connects")}
function markMoment(type){let time=currentSeconds(),n=countType(type)+1,code=`${type==="unclear"?"U":"C"}${n}`;state.markers.push({id:uid(),type,code,time,replayTime:Math.max(0,time-30),createdAt:Date.now()});saveStudentProgress();updateLectureUI()}
function reviewMedia(){
  if(state.sessionMode==="recorded"&&state.lectureURL){
    let isAudio=state.lectureFile?.type?.startsWith("audio/");
    if(isAudio){
      return `<div class="recording-ready student-recording"><div class="recording-ready-top"><strong>Lecture recording is ready.</strong><a class="btn btn-secondary" href="${state.lectureURL}" download="unfolded-lecture-recording.webm">Download recording</a></div><audio id="reviewMedia" controls src="${state.lectureURL}"></audio></div>`;
    }
    return `<div class="review-media compact-media"><video id="reviewMedia" controls src="${state.lectureURL}"></video></div>`;
  }
  let au=lectureAudioURL();
  return au?`<div class="recording-ready student-recording"><div class="recording-ready-top"><strong>Lecture recording is ready.</strong><a class="btn btn-secondary" href="${au}" download="unfolded-live-lecture-recording.webm">Download recording</a></div><audio id="reviewMedia" controls src="${au}"></audio></div>`:`<div class="note-box">No lecture audio is attached to this review yet.</div>`;
}
function lectureAudioURL(){return state.activeLecture?.audio?.audioDataURL||state.currentLectureAudioDataURL||""}
function getLectureDuration(){let media=document.getElementById("reviewMedia")||document.getElementById("lectureMedia");if(media&&isFinite(media.duration)&&media.duration>0)return Math.floor(media.duration);if(state.sessionMode==="live"&&state.activeLecture?.startedAt&&state.activeLecture?.endedAt)return Math.max(0,Math.floor((state.activeLecture.endedAt-state.activeLecture.startedAt)/1000));return Math.max(...state.markers.map(m=>m.time||0),60)}
function lecturerRecordingBlock(){let au=state.localRecordingURL||state.activeLecture?.audio?.audioDataURL||"";if(!au)return"";return `<div class="recording-ready"><div class="recording-ready-top"><strong>Recording is ready.</strong><a class="btn btn-secondary" href="${au}" download="unfolded-live-lecture-recording.webm">Download recording</a></div><audio controls src="${au}"></audio></div>`}
function submissionAudioBlock(s){let au=s?.lectureAudioDataURL||"";if(!au)return"";return `<article class="reflection-card session-summary"><strong>Lecture recording for this submission</strong><audio class="submission-audio" controls src="${au}"></audio><a class="note-download" href="${au}" download="unfolded-submission-lecture-recording.webm">Download recording</a></article>`}
function noteUploadBlock(){return `<section class="card note-upload-card"><div><h3>Attach handwritten notes</h3><p>Upload one or more photos of your handwritten notes</p></div><div class="file-box"><input id="noteUpload" type="file" accept="image/*" multiple></div>${state.noteFiles&&state.noteFiles.length?`<div class="note-preview-grid">${state.noteFiles.map((f,i)=>`<div class="note-preview"><img src="${f.data}" alt="Handwritten note ${i+1}"><span>${esc(f.name||`Note ${i+1}`)}</span></div>`).join("")}</div>`:`<p class="small-muted">No handwritten notes attached yet.</p>`}</section>`}
async function handleNoteFiles(e){let files=[...(e.target.files||[])];if(!files.length)return;let loaded=[];for(let file of files){if(!file.type.startsWith("image/")){toast("Please upload image files for handwritten notes.","warning");continue}let data=await readFileAsDataURL(file);loaded.push({name:file.name,type:file.type,data})}state.noteFiles=[...(state.noteFiles||[]),...loaded];saveStudentProgress();render()}
function readFileAsDataURL(file){return new Promise((resolve,reject)=>{let reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(file)})}
function renderReview(){
  shell(`<section class="review-layout review-page"><div class="review-head"><div><h2>Student Review</h2><p><strong>Session:</strong> ${esc(state.sessionTitle||state.activeLecture?.title||"Untitled Lecture")}</p><p><strong>Student name:</strong> ${esc(state.name||"Anonymous")}</p><p><strong>Status:</strong> ${state.submitted?"Submitted":"Not submitted yet"}</p></div><div class="btn-row review-actions"><button class="btn btn-secondary" id="profileReviewBtn">View Badges</button><button class="btn btn-muted" id="backToLectureBtn">Back to Summary</button></div></div>${reviewMedia()}<div class="timeline"><div class="timeline-title-row"><h3>Your learning trace</h3><div class="legend"><span><i class="dot unclear-dot"></i>Unclear</span><span><i class="dot connect-dot"></i>Connects</span></div></div><div class="timeline-wrap"><span class="time-label start">00:00</span><div class="timeline-track">${timelineMarkers()}</div><span class="time-label end">${timelineEndLabel()}</span></div></div>${noteUploadBlock()}<div class="review-cards">${state.markers.length?state.markers.map(renderMarkerReview).join(""):`<div class="empty-state">No markers yet.</div>`}</div>${questionnaireBlock()}<div class="bottom-submit">${state.submitted?`<button class="btn btn-primary" id="doneBtn">Done / Close</button>`:`<button class="btn btn-primary" id="submitBtn">Submit to Lecturer</button>`}</div></section>`);
  document.getElementById("backToLectureBtn").onclick=()=>{state.view="lecture";render()};let profileReviewBtn=document.getElementById("profileReviewBtn");if(profileReviewBtn)profileReviewBtn.onclick=()=>{state.view=state.studentAuth?"studentProfile":"studentLogin";render()};
  let notesInput=document.getElementById("noteUpload");if(notesInput)notesInput.onchange=handleNoteFiles;
  let submit=document.getElementById("submitBtn");if(submit)submit.onclick=submitSession;
  let done=document.getElementById("doneBtn");if(done)done.onclick=()=>{state.view="studentStart";state.sessionMode="recorded";state.joinedLive=false;render()};
  state.markers.forEach(m=>{let replay=document.getElementById(`replay-${m.id}`);if(replay)replay.onclick=()=>replayMarker(m);let share=document.getElementById(`share-${m.id}`);if(share)share.onchange=e=>{state.shareSettings[m.id]=e.target.value;saveStudentProgress()}});
  document.querySelectorAll("[data-marker-id]").forEach(btn=>{btn.onclick=()=>{let ids=(btn.dataset.markerId||"").split(",");let marker=state.markers.find(m=>m.id===ids[0])||state.markers.find(m=>ids.includes(m.id));if(marker)replayMarker(marker)}});
  let rm=document.getElementById("reviewMedia");if(rm)rm.onloadedmetadata=()=>{let end=document.querySelector(".timeline .time-label.end");if(end)end.textContent=timelineEndLabel()};
  document.querySelectorAll("[data-reflection-key]").forEach(input=>{let save=e=>{state.reflections[e.target.dataset.reflectionKey]=e.target.value;saveStudentProgress()};input.oninput=save;input.onchange=save});
  document.querySelectorAll("[data-question-id]").forEach(input=>{input.onpaste=e=>{e.preventDefault();toast("Paste is disabled. Please write in your own words.","warning")};input.oninput=e=>{state.questionnaireAnswers[e.target.dataset.questionId]=e.target.value;saveStudentProgress()}});
}
function timelineEndLabel(){return formatTime(getLectureDuration()||60)}
function timelineMarkers(){
  if(!state.markers.length)return"";
  let duration=Math.max(getLectureDuration(),60);
  let sorted=[...state.markers].sort((a,b)=>a.time-b.time),groups=[];
  sorted.forEach(m=>{let g=groups[groups.length-1];if(g&&Math.abs((g.avg||g.items[0].time)-m.time)<=3){g.items.push(m);g.avg=g.items.reduce((s,x)=>s+x.time,0)/g.items.length}else groups.push({items:[m],avg:m.time})});
  return groups.map(g=>{let hasU=g.items.some(x=>x.type==="unclear"),hasC=g.items.some(x=>x.type==="connects"),cls=hasU&&hasC?"mixed":hasU?"unclear":"connects",label=g.items.length===1?g.items[0].code:g.items.map(x=>x.code).join("/");let title=g.items.map(x=>`${x.code} at ${formatTime(x.time)}`).join(" • ");let ids=g.items.map(x=>x.id).join(",");return `<button type="button" class="timeline-marker ${cls}" data-marker-id="${esc(ids)}" style="left:${Math.max(4,Math.min(96,g.avg/duration*100))}%" title="Replay ${esc(title)}"><span>${esc(label)}</span></button>`}).join("")
}
function renderMarkerReview(m){
  let share=state.shareSettings[m.id]||"anonymous",kind=m.type==="unclear"?"Unclear":"Connects",prefix=m.id+":";
  if(m.type==="unclear"){
    return `<article class="marker-review"><div class="marker-review-top"><h3>${m.code} · ${kind} · ${formatTime(m.time)}</h3><button class="btn btn-primary replay-btn" type="button" id="replay-${m.id}">Replay moment</button></div><div class="form-stack"><label>What was on the screen or being discussed when you felt unclear?</label><textarea data-reflection-key="${prefix}around" placeholder="Example: a word, slide, diagram, example, or part of the explanation">${esc(state.reflections[prefix+"around"]||"")}</textarea><label>What feels unclear?</label><textarea data-reflection-key="${prefix}unclear" placeholder="I do not understand...">${esc(state.reflections[prefix+"unclear"]||"")}</textarea><label>After replaying, what happened?</label><div class="select-wrap"><select data-reflection-key="${prefix}after"><option value="">Choose one</option><option ${state.reflections[prefix+"after"]==="I understand now"?"selected":""}>I understand now</option><option ${state.reflections[prefix+"after"]==="I partly understand"?"selected":""}>I partly understand</option><option ${state.reflections[prefix+"after"]==="I am still confused"?"selected":""}>I am still confused</option><option ${state.reflections[prefix+"after"]==="I need an example"?"selected":""}>I need an example</option><option ${state.reflections[prefix+"after"]==="I need lecturer help"?"selected":""}>I need lecturer help</option></select></div><label>Type your understanding or what still feels unclear.</label><textarea data-reflection-key="${prefix}understanding" placeholder="Write what you understand now">${esc(state.reflections[prefix+"understanding"]||"")}</textarea><label>What help would be useful?</label><textarea data-reflection-key="${prefix}help" placeholder="Example, review slide, explain again...">${esc(state.reflections[prefix+"help"]||"")}</textarea></div>${shareSelect(m,share)}</article>`;
  }
  return `<article class="marker-review"><div class="marker-review-top"><h3>${m.code} · ${kind} · ${formatTime(m.time)}</h3><button class="btn btn-primary replay-btn" type="button" id="replay-${m.id}">Replay moment</button></div><div class="form-stack"><label>What was on the screen or being discussed when you made this connection?</label><textarea data-reflection-key="${prefix}around" placeholder="Example: a concept, example, image, or idea that reminded you of something">${esc(state.reflections[prefix+"around"]||"")}</textarea><label>What idea did this connect to?</label><textarea data-reflection-key="${prefix}connect" placeholder="This connected to...">${esc(state.reflections[prefix+"connect"]||"")}</textarea><label>Why did this connection help?</label><textarea data-reflection-key="${prefix}why" placeholder="It helped because...">${esc(state.reflections[prefix+"why"]||"")}</textarea></div>${shareSelect(m,share)}</article>`;
}
function shareSelect(m,share){return `<div class="share-block"><label for="share-${m.id}">Share setting</label><div class="select-wrap"><select id="share-${m.id}"><option value="private" ${share==="private"?"selected":""}>Private</option><option value="anonymous" ${share==="anonymous"?"selected":""}>Anonymous</option><option value="named" ${share==="named"?"selected":""}>Named</option></select></div></div>`}
function questionnaireBlock(){let questions=[];if(state.sessionMode==="live"){let l=state.activeLecture;if(l?.questionnaireEnabled&&Array.isArray(l.questions))questions=l.questions}else if(state.sessionMode==="recorded"){questions=state.recordedQuestionnaireEnabled!==false?state.recordedQuestionnaire||[]:[]}questions=(questions||[]).filter(Boolean);if(!questions.length)return"";return `<div class="card"><h3>Post-lecture questionnaire</h3><div class="form-stack">${questions.map((q,i)=>`<label for="question-${i}">${esc(q)}</label><textarea id="question-${i}" data-question-id="q${i}" placeholder="Write in your own words.">${esc(state.questionnaireAnswers[`q${i}`]||"")}</textarea>`).join("")}</div></div>`}
function replayMarker(m){
  if(m&&m.id){state.replayedMarkers[m.id]=true;saveStudentProgress();}
  let media=document.getElementById("reviewMedia");
  if(media){
    // Move the student back to the lecture recording first, then replay from the marked moment.
    let mediaSection=media.closest(".review-media")||media;
    mediaSection.scrollIntoView({behavior:"smooth",block:"center"});
    setTimeout(()=>{
      try{media.currentTime=m.replayTime||0}catch(e){}
      media.play().catch(()=>toast("Press play to replay this moment.","info"));
      media.focus?.();
    },260);
  }else toast("No recording is attached to replay.","info")
}
function collectReflection(m){let prefix=m.id+":";let parts=[];Object.keys(state.reflections).filter(k=>k.startsWith(prefix)).forEach(k=>{let label=k.split(":")[1]||"reflection",val=(state.reflections[k]||"").trim();if(val)parts.push(`${label}: ${val}`)});return parts.join("\n") || state.reflections[m.id] || ""}
async function submitSession(){
  if(state.submitted){toast("This review was already submitted.","info");return;}
  let btn=document.getElementById("submitBtn");if(btn){btn.disabled=true;btn.textContent="Submitting...";}
  let shared=state.markers.map(m=>{let share=state.shareSettings[m.id]||"anonymous";return{code:m.code,type:m.type,time:m.time,replayTime:m.replayTime,share,studentName:share==="named"?state.name:"",reflection:collectReflection(m)}}).filter(m=>m.share!=="private");
  let audioURL=state.sessionMode==="live"?lectureAudioURL():"";
  let data={sessionTitle:state.sessionTitle||state.activeLecture?.title||"Untitled session",studentUid:state.studentAuth?.uid||"",studentEmail:state.studentAuth?.email||"",studentName:state.name||state.studentAuth?.displayName||"Anonymous",mode:state.sessionMode,lectureId:state.activeLecture?.id||"",lectureDuration:getLectureDuration(),lectureStartedAt:state.activeLecture?.startedAt||state.currentStartedAt||null,lectureEndedAt:state.activeLecture?.endedAt||null,lectureAudioDataURL:audioURL,lectureAudioType:state.activeLecture?.audio?.audioType||"audio/webm",submittedAt:new Date().toISOString(),totalMarkers:state.markers.length,unclearCount:countType("unclear"),connectsCount:countType("connects"),privateCount:state.markers.filter(m=>(state.shareSettings[m.id]||"anonymous")==="private").length,recordingUploaded:Boolean(state.lectureURL||audioURL),sharedMarkers:shared,questionnaireAnswers:state.questionnaireAnswers,questionnaireQuestions:state.sessionMode==="recorded"?(state.recordedQuestionnaire||[]):(state.activeLecture?.questions||[]),handwrittenNotes:state.noteFiles||[],pauseAnswers:state.pauseAnswers||{},badgesUnlocked:getStudentBadges().filter(b=>b.unlocked).map(b=>b.title)};
  try{await classRef("sessions").push(data);state.submitted=true;saveStudentProgress();confetti();toast("Submitted. Badges updated.","success",1200);render()}catch(e){if(btn){btn.disabled=false;btn.textContent="Submit to Lecturer";}toast("Submission failed. Check Firebase and try again.","warning",4200);console.error(e)}
}
function renderLecturerLogin(){renderAuthPage("lecturer")}

function liveQuestionnaireInputs(){return `<div class="question-card live-questionnaire-box compact-question-card"><h4>Live post-lecture questionnaire</h4><p>These questions appear on student review after the live lecture ends.</p><label class="checkline"><input type="checkbox" id="enableQuestions" ${state.activeLecture?.questionnaireEnabled?"checked":""}>Send post-lecture questionnaire</label><div class="question-list compact-list">${state.lecturerQuestions.map((q,i)=>`<input type="text" class="questionInput" data-index="${i}" value="${esc(q)}" placeholder="Question ${i+1}">`).join("")}</div></div>`}
function renderLecturerDashboard(){if(!state.lecturerAuth){state.view="lecturerLogin";return renderLecturerLogin()}let l=state.activeLecture,s=l?.status||"none";shell(`<section class="dashboard lecturer-dashboard"><div class="dashboard-header"><div><h2>Lecturer Dashboard</h2><p>Control live lectures, recorded lecture questions, and student submissions.</p></div></div><section class="card live-control"><div class="dashboard-header"><div><h3>Live Lecture Control</h3><span class="status-pill ${statusClass(s)}">${statusLabel(s)}</span></div></div><div class="live-top-row"><div class="live-title-block"><label for="liveTitle">Live lecture title</label><input id="liveTitle" type="text" placeholder="Lecture title" value="${esc(l?.title==="Untitled Live Lecture"?"":(l?.title||""))}"><p class="small-muted">Live audio is automatically attached to student review after the lecture ends.</p></div><div class="live-actions-block"><div class="btn-row"><button class="btn btn-secondary" id="prepareLectureBtn">Prepare Live Lecture</button><button class="btn btn-primary" id="startLectureBtn">Start Live Lecture</button><button class="btn btn-danger" id="endLectureBtn">End Live Lecture</button></div>${lecturerRecordingBlock()}</div></div><div class="live-control-layout">${renderLiveQuestionPanel()}${liveQuestionnaireInputs()}</div></section>${renderRecordedLectureControl()}<section class="stats"><div class="stat-card"><strong>${state.submissions.length}</strong><span>Student submissions</span></div><div class="stat-card"><strong>${sharedCount()}</strong><span>Shared markers</span></div><div class="stat-card"><strong>${typeCount("unclear")}</strong><span>Unclear markers</span></div><div class="stat-card"><strong>${typeCount("connects")}</strong><span>Connect markers</span></div><div class="stat-card"><strong>${needHelpCount()}</strong><span>Need help</span></div></section><section class="filter-grid"><div><label>Check student submission</label><div class="select-wrap"><select id="studentFilter"><option value="all">All students</option>${state.submissions.map((s,i)=>`<option value="${i}" ${String(i)===String(state.selectedStudent)?"selected":""}>${esc(s.studentName||"Anonymous")} · ${esc(s.sessionTitle||"Untitled")}</option>`).join("")}</select></div></div><div><label>Visualization</label><div class="select-wrap"><select id="vizFilter"><option value="combined" ${state.selectedViz==="combined"?"selected":""}>Combined activity</option><option value="unclear" ${state.selectedViz==="unclear"?"selected":""}>Unclear moments</option><option value="connects" ${state.selectedViz==="connects"?"selected":""}>Connect moments</option></select></div></div></section><section class="card visualization-panel"><h3>${vizTitle()}</h3>${vizDesc()?`<p>${vizDesc()}</p>`:""}<div class="bar-chart">${renderBars()}</div>${activeWindowText()}</section><section class="card dashboard-timeline-panel"><h3>Timeline visualization</h3><div class="dashboard-timeline-track">${renderDashboardTimeline()}</div></section><section><h3>Submitted reflections</h3><div class="reflection-list">${renderReflectionList()}</div></section></section>`);document.getElementById("prepareLectureBtn").onclick=prepareLecture;document.getElementById("startLectureBtn").onclick=startLiveLecture;document.getElementById("endLectureBtn").onclick=endLiveLecture;document.getElementById("studentFilter").onchange=e=>{preserveNextScroll=true;state.selectedStudent=e.target.value;render()};document.getElementById("vizFilter").onchange=e=>{preserveNextScroll=true;state.selectedViz=e.target.value;render()};document.querySelectorAll(".questionInput").forEach(input=>input.oninput=e=>state.lecturerQuestions[+e.target.dataset.index]=e.target.value);document.getElementById("sendLiveQuestionBtn").onclick=sendLiveQuestion;document.getElementById("clearLiveQuestionBtn").onclick=clearLiveQuestion;document.getElementById("addRecordedQuestionBtn").onclick=addRecordedQuestion;let rqBtn=document.getElementById("saveRecordedQuestionnaireBtn");if(rqBtn)rqBtn.onclick=saveRecordedQuestionnaire;document.querySelectorAll(".mini-delete").forEach(btn=>btn.onclick=()=>removeRecordedQuestion(+btn.dataset.qindex));document.querySelectorAll("[data-dashboard-replay]").forEach(btn=>btn.onclick=()=>replayDashboardMoment(btn.dataset.dashboardReplay))}
function lecturePayload(status){let title=document.getElementById("liveTitle").value.trim()||"Live Lecture",questionnaireEnabled=document.getElementById("enableQuestions")?.checked||false,questions=[...document.querySelectorAll(".questionInput")].map(i=>i.value.trim()).filter(Boolean).slice(0,5);return{title,recordingEnabled:true,questionnaireEnabled,questions,status}}
async function prepareLecture(){let p=lecturePayload("ready");await classRef("activeLecture").set({id:uid(),...p,createdAt:Date.now(),hasAudio:false});toast("Live lecture is prepared and visible on the student page.","success")}
async function startLiveLecture(){let p=lecturePayload("live");state.localRecordingURL="";state.currentLectureAudioDataURL="";state.recordedChunks=[];await classRef("activeLecture").update({id:state.activeLecture?.id||uid(),...p,startedAt:Date.now(),endedAt:null,hasAudio:false,audio:null});await startLocalAudioRecording();toast("Live lecture started. Student screens will update automatically.","success")}
async function endLiveLecture(){if(state.mediaRecorder&&state.mediaRecorder.state!=="inactive"){state.mediaRecorder.stop();return}await finishEndingLiveLecture(false)}
async function startLocalAudioRecording(){try{let stream=await navigator.mediaDevices.getUserMedia({audio:true});state.mediaRecorder=new MediaRecorder(stream);state.recordedChunks=[];state.mediaRecorder.ondataavailable=e=>{if(e.data.size>0)state.recordedChunks.push(e.data)};state.mediaRecorder.onstop=async()=>{let blob=new Blob(state.recordedChunks,{type:"audio/webm"});state.localRecordingURL=URL.createObjectURL(blob);stream.getTracks().forEach(t=>t.stop());let dataURL=await blobToDataURL(blob);state.currentLectureAudioDataURL=dataURL;await classRef("activeLecture/audio").set({audioDataURL:dataURL,audioType:blob.type,uploadedAt:Date.now()});await finishEndingLiveLecture(true)};state.mediaRecorder.start();toast("Audio recording started.","success")}catch(e){toast("Microphone could not start. Live lecture will continue without audio recording.","warning");console.error(e)}}function blobToDataURL(blob){return new Promise((res,rej)=>{let r=new FileReader();r.onload=()=>res(r.result);r.onerror=rej;r.readAsDataURL(blob)})}async function finishEndingLiveLecture(hasAudio){let endedAt=Date.now();let update={status:"ended",endedAt,hasAudio:Boolean(hasAudio)};await classRef("activeLecture").update(update);let snap=await classRef("activeLecture").once("value");let lecture=snap.val();if(lecture?.id)await classRef("lectureArchive/"+lecture.id).set({...lecture,...update,archivedAt:Date.now()});if(lecture?.audio?.audioDataURL)state.currentLectureAudioDataURL=lecture.audio.audioDataURL;toast(hasAudio?"Live lecture ended. The audio is now attached to student review.":"Live lecture ended.","success");if(state.view==="lecturer")render()}
function listenForActiveLecture(){classRef("activeLecture").on("value",snap=>{let prev=state.activeLecture?.status,prevQ=state.activeLecture?.liveQuestion?.id;state.activeLecture=snap.val();if(state.activeLecture?.liveQuestion)state.activeLecture.liveQuestion=normalizeQuestionObject(state.activeLecture.liveQuestion)||state.activeLecture.liveQuestion;if(state.sessionMode==="live"&&state.joinedLive&&state.activeLecture){if(state.activeLecture.status==="live"&&prev!=="live"){state.currentStartedAt=state.activeLecture.startedAt||Date.now();toast("Live lecture started.","success");render()}if(state.activeLecture.status==="ended"&&prev!=="ended"){toast("Live lecture ended. Review is now available.","success");render()}if(state.activeLecture.liveQuestion&&state.activeLecture.liveQuestion.id!==prevQ)maybeShowLiveQuestion()}else if(state.view==="studentStart"||state.view==="studentProfile"||state.view==="lecturer")render()})}
function listenForLiveQuestion(){classRef("activeLecture/liveQuestion").on("value",snap=>{let q=normalizeQuestionObject(snap.val());if(state.activeLecture)state.activeLecture.liveQuestion=q;else if(q)state.activeLecture={liveQuestion:q};if(q&&state.sessionMode==="live"&&state.joinedLive&&state.view==="lecture"&&!state.pauseAnswers[q.id])showPauseQuestion(q,"live")})}
function listenForRecordedQuestions(){classRef("recordedQuestions").on("value",snap=>{state.recordedPauseQuestions=normalizeRecordedQuestions(snap.val());if(state.view==="lecturer")render()});classRef("recordedQuestionnaire").on("value",snap=>{state.recordedQuestionnaire=normalizeQuestionnaire(snap.val());if(state.view==="lecturer")render()});classRef("recordedQuestionnaireEnabled").on("value",snap=>{state.recordedQuestionnaireEnabled=snap.val()!==false;if(state.view==="lecturer")render()})}function listenForSubmissions(){classRef("sessions").on("value",snap=>{let v=snap.val()||{};state.submissions=Object.entries(v).map(([id,d])=>({id,...d})).sort((a,b)=>new Date(b.submittedAt||0)-new Date(a.submittedAt||0));if(state.view==="lecturer")render()})}
function filteredSubs(){return state.selectedStudent==="all"?state.submissions:(state.submissions[+state.selectedStudent]?[state.submissions[+state.selectedStudent]]:[])}function sharedCount(){return state.submissions.reduce((s,x)=>s+(x.sharedMarkers?.length||0),0)}function typeCount(t){return state.submissions.reduce((s,x)=>s+(x.sharedMarkers||[]).filter(m=>m.type===t).length,0)}function needHelpCount(){return state.submissions.reduce((sum,x)=>sum+(x.sharedMarkers||[]).filter(m=>{let r=String(m.reflection||"").toLowerCase();return r.includes("i need lecturer help")||r.includes("need lecturer help")||/help:\s*[^\n]/.test(r)}).length,0)}function vizTitle(){return state.selectedViz==="unclear"?"Unclear moments":state.selectedViz==="connects"?"Connect moments":"Combined activity"}function vizDesc(){return ""}function getDashboardMarkers(){return filteredSubs().flatMap(s=>(s.sharedMarkers||[]).map(m=>({...m,student:s.studentName,session:s.sessionTitle,submissionId:s.id,lectureDuration:s.lectureDuration,questionnaireAnswers:s.questionnaireAnswers,questionnaireQuestions:s.questionnaireQuestions,handwrittenNotes:s.handwrittenNotes||[]}))).filter(m=>state.selectedViz==="combined"||m.type===state.selectedViz)}
function dashboardBuckets(){let markers=getDashboardMarkers(),by={};markers.forEach(m=>{let min=Math.floor((m.time||0)/60);if(!by[min])by[min]={unclear:0,connects:0,total:0};by[min][m.type]=(by[min][m.type]||0)+1;by[min].total++});return by}function activeWindowText(){let by=dashboardBuckets(),mins=Object.keys(by).map(Number);if(!mins.length)return"";let best=mins.sort((a,b)=>by[b].total-by[a].total||a-b)[0],count=by[best].total;return `<p class="active-window">Most active window: ${formatTime(best*60)}–${formatTime((best+1)*60)} with ${count} shared marker(s).</p>`}function renderBars(){let by=dashboardBuckets();let mins=Object.keys(by).map(Number).sort((a,b)=>a-b);if(!mins.length)return`<div class="empty-state">No shared markers yet.</div>`;let max=Math.max(...mins.map(min=>by[min].total),1);return mins.map(min=>{let info=by[min],count=info.total,h=28+count/max*110,cls="combined";if(info.unclear&&!info.connects)cls="unclear";if(info.connects&&!info.unclear)cls="connects";return`<div class="bar-item" title="${count} marker(s) at ${min}:00"><div class="bar-count">${count}</div><div class="bar ${cls}" style="height:${h}px"></div><div class="bar-label">${min}:00</div></div>`}).join("")}
function getDashboardDuration(){let subs=filteredSubs();let d=Math.max(...subs.map(s=>Number(s.lectureDuration)||0),...getDashboardMarkers().map(m=>Number(m.time)||0),60);return Math.max(d,60)}
function renderDashboardTimeline(){let markers=getDashboardMarkers();if(!markers.length)return`<div class="empty-state">No markers for this view yet.</div>`;let duration=getDashboardDuration();let markerHtml=markers.map(m=>`<button type="button" data-dashboard-replay="${esc(m.session||"")}|||${esc(m.code||"")}" class="timeline-marker ${m.type}" style="left:${Math.max(3,Math.min(97,(m.time||0)/duration*100))}%" title="Replay ${esc(m.code)} at ${formatTime(m.time||0)}">${esc(m.code)}</button>`).join("");return`<div class="timeline-wrap dashboard-timeline-wrap"><span class="time-label start">00:00</span><div class="timeline-track">${markerHtml}</div><span class="time-label end">${formatTime(duration)}</span></div>`}
function replayDashboardMoment(key){let [sessionTitle,code]=String(key||"").split("|||");let sub=filteredSubs().find(s=>(s.sharedMarkers||[]).some(m=>m.code===code)&&(s.sessionTitle||"")===sessionTitle)||filteredSubs().find(s=>(s.sharedMarkers||[]).some(m=>m.code===code));let marker=sub?.sharedMarkers?.find(m=>m.code===code);if(!sub||!marker){toast("This timeline marker could not be opened.","warning");return}let existing=document.getElementById("submissionReplayModal");if(existing)existing.remove();let audio=sub.lectureAudioDataURL||"";let modal=document.createElement("div");modal.id="submissionReplayModal";modal.className="help-modal active";modal.innerHTML=`<div class="help-card"><div class="dashboard-header"><div><h3>${esc(marker.code)} · ${marker.type==="unclear"?"Unclear":"Connect"} · ${formatTime(marker.time||0)}</h3><p>${esc(sub.studentName||"Anonymous")} · ${esc(sub.sessionTitle||"Untitled session")}</p></div><button class="btn btn-muted" id="closeSubmissionReplay">Close</button></div>${audio?`<audio id="submissionReplayAudio" controls src="${audio}"></audio><p class="small-muted">Replay starts near ${formatTime(marker.replayTime??Math.max(0,(marker.time||0)-30))}.</p>`:`<div class="note-box">No lecture recording is attached to this submission.</div>`}</div>`;document.body.appendChild(modal);document.getElementById("closeSubmissionReplay").onclick=()=>modal.remove();modal.onclick=e=>{if(e.target===modal)modal.remove()};let player=document.getElementById("submissionReplayAudio");if(player){player.onloadedmetadata=()=>{player.currentTime=Math.max(0,marker.replayTime??Math.max(0,(marker.time||0)-30));player.play().catch(()=>{})}}}
function renderQuestionnaireAnswersForSession(s){let qa=s.questionnaireAnswers||{},questions=s.questionnaireQuestions||[];let entries=Object.entries(qa).filter(([k,v])=>String(v||"").trim());if(!entries.length)return"";return `<div class="qa-summary"><strong>Post-lecture questionnaire</strong>${entries.map(([k,v],i)=>{let q=questions[i]||`Q${i+1}`;return `<p><b>${esc(q)}:</b> ${esc(v)}</p>`}).join("")}</div>`}
function renderHandwrittenNotes(notes){if(!notes||!notes.length)return"";let start=window.__noteStore.length;notes.forEach(n=>window.__noteStore.push(n));return `<div class="handwritten-notes"><strong>Attached handwritten notes</strong><div class="note-thumb-grid">${notes.map((n,i)=>`<button type="button" class="note-thumb" onclick="openNoteIndex(${start+i})"><img src="${n.data}" alt="Handwritten note ${i+1}"><span>${esc(n.name||`Note ${i+1}`)}</span></button>`).join("")}</div></div>`}
function renderSessionAttachments(s){let notes=renderHandwrittenNotes(s.handwrittenNotes||[]);let qa=renderQuestionnaireAnswersForSession(s);if(!notes&&!qa)return"";return `<article class="reflection-card session-summary"><strong>${esc(s.studentName||"Anonymous")} · ${esc(s.sessionTitle||"Untitled session")}</strong>${notes}${qa}</article>`}
function renderReflectionList(){window.__noteStore=[];let html="";let total=0;filteredSubs().forEach(s=>{let markers=(s.sharedMarkers||[]).filter(m=>state.selectedViz==="combined"||m.type===state.selectedViz);if(!markers.length)return;total+=markers.length;html+=submissionAudioBlock(s);html+=renderSessionAttachments(s);html+=markers.map(m=>`<article class="reflection-card"><strong>${esc(m.code)} · ${m.type==="unclear"?"Unclear":"Connect"} · ${formatTime(m.time||0)}</strong><p>${m.share==="named"?esc(s.studentName||"Anonymous"):"Anonymous"} · ${esc(s.sessionTitle||"Untitled session")}</p><p>${esc(m.reflection||"No written reflection shared.")}</p></article>`).join("")});return total?html:`<div class="empty-state">No shared reflections yet.</div>`}
function renderHelpModal(){if(document.getElementById("helpModal"))return;let modal=document.createElement("div");modal.id="helpModal";modal.className="help-modal";modal.innerHTML=`<div class="help-card"><div class="dashboard-header"><h3>How UnfoldED works</h3><button class="btn btn-muted" id="closeHelp">Close</button></div><div class="help-grid"><div class="help-item"><strong>Live lecture</strong><p>The lecturer prepares, starts, and ends the live lecture. Students can mark learning moments while the lecture is running.</p></div><div class="help-item"><strong>Recorded lecture</strong><p>Students upload a lecture recording, mark moments during playback, and review their timeline afterward.</p></div><div class="help-item"><strong>Unclear</strong><p>Use this when a concept feels confusing, incomplete, or needs another example.</p></div><div class="help-item"><strong>Connects</strong><p>Use this when a concept connects to prior knowledge, another class, or a personal experience.</p></div><div class="help-item"><strong>Share setting</strong><p><b>Private:</b> Not shared with the lecturer. It stays in your own learning dashboard for personal reflection.</p><p><b>Anonymous:</b> Shared with the lecturer without your name or initials.</p><p><b>Named:</b> Shared with the lecturer with your name or initials so they can follow up if needed.</p></div><div class="help-item"><strong>Post-lecture questionnaire</strong><p>If the lecturer enables it, you can answer follow-up questions after the lecture.</p></div><div class="help-item"><strong>Full screen</strong><p>Use the Full screen button to enter or exit. You can also press F when you are not typing, and ESC to exit.</p></div></div></div>`;document.body.appendChild(modal);modal.onclick=e=>{if(e.target===modal)modal.classList.remove("active")};document.getElementById("closeHelp").onclick=()=>modal.classList.remove("active")}
(async()=>{state.studentAuth=null;state.lecturerAuth=null;state.studentSavedSessions={};listenForActiveLecture();listenForLiveQuestion();listenForRecordedQuestions();await loadSavedStudent();restoreAppStateAfterAuth();if(state.lecturerAuth)listenForSubmissions();render();})();

// v9: handwritten note lightbox viewer
window.openNoteIndex = function(index){
  const notes = window.__noteStore || [];
  const note = notes[index];
  if(!note || !note.data){
    toast("This note image could not be opened.", "warning");
    return;
  }
  const existing = document.getElementById("noteLightbox");
  if(existing) existing.remove();
  const modal = document.createElement("div");
  modal.id = "noteLightbox";
  modal.className = "note-lightbox";
  modal.innerHTML = `
    <div class="note-lightbox-card" role="dialog" aria-modal="true" aria-label="Handwritten note preview">
      <div class="note-lightbox-head">
        <div class="note-lightbox-title">${esc(note.name || "Handwritten note")}</div>
        <button class="btn btn-muted" id="closeNoteLightbox">Close</button>
      </div>
      <img class="note-lightbox-img" src="${note.data}" alt="${esc(note.name || "Handwritten note")}">
    </div>`;
  document.body.appendChild(modal);
  const close = () => modal.remove();
  document.getElementById("closeNoteLightbox").onclick = close;
  modal.onclick = (e) => { if(e.target === modal) close(); };
};

// v11: center empty visualization states and add note downloads
function safeDownloadName(name, index){
  const fallback = `handwritten-note-${index+1}.png`;
  return String(name || fallback).replace(/[\\/:*?"<>|]+/g, "-");
}
function renderHandwrittenNotes(notes){
  if(!notes||!notes.length)return"";
  let start=window.__noteStore.length;
  notes.forEach(n=>window.__noteStore.push(n));
  return `<div class="handwritten-notes"><strong>Attached handwritten notes</strong><div class="note-thumb-grid">${notes.map((n,i)=>`<div class="note-thumb-card"><button type="button" class="note-thumb note-thumb-preview" onclick="openNoteIndex(${start+i})"><img src="${n.data}" alt="Handwritten note ${i+1}"><span>${esc(n.name||`Note ${i+1}`)}</span></button><a class="note-download" href="${n.data}" download="${esc(safeDownloadName(n.name,i))}">Download</a></div>`).join("")}</div></div>`;
}
window.openNoteIndex = function(index){
  const notes = window.__noteStore || [];
  const note = notes[index];
  if(!note || !note.data){
    toast("This note image could not be opened.", "warning");
    return;
  }
  const existing = document.getElementById("noteLightbox");
  if(existing) existing.remove();
  const fileName = safeDownloadName(note.name, index);
  const modal = document.createElement("div");
  modal.id = "noteLightbox";
  modal.className = "note-lightbox";
  modal.innerHTML = `
    <div class="note-lightbox-card" role="dialog" aria-modal="true" aria-label="Handwritten note preview">
      <div class="note-lightbox-head">
        <div class="note-lightbox-title">${esc(note.name || "Handwritten note")}</div>
        <div class="note-lightbox-actions">
          <a class="btn btn-muted note-lightbox-download" href="${note.data}" download="${esc(fileName)}">Download</a>
          <button class="btn btn-muted" id="closeNoteLightbox">Close</button>
        </div>
      </div>
      <img class="note-lightbox-img" src="${note.data}" alt="${esc(note.name || "Handwritten note")}">
    </div>`;
  document.body.appendChild(modal);
  const close = () => modal.remove();
  document.getElementById("closeNoteLightbox").onclick = close;
  modal.onclick = (e) => { if(e.target === modal) close(); };
};
if(state.view === "lecturer") render();

/* v14: lecturer follow-up responses + stronger own-words input protection */
state.lecturerResponses = state.lecturerResponses || {};

function disablePasteForOwnWords(root=document){
  const fields = root.querySelectorAll('[data-question-id], [data-reflection-key]');
  fields.forEach(field=>{
    field.setAttribute('data-own-words','true');
    field.setAttribute('autocomplete','off');
    field.onpaste = e => {
      e.preventDefault();
      toast('Paste is disabled. Please rewrite this in your own words.', 'warning');
    };
    field.ondrop = e => {
      e.preventDefault();
      toast('Dropping text is disabled. Please write in your own words.', 'warning');
    };
    field.addEventListener('beforeinput', e => {
      if(e.inputType === 'insertFromPaste' || e.inputType === 'insertFromDrop'){
        e.preventDefault();
        toast('Paste is disabled. Please write in your own words.', 'warning');
      }
    });
  });
}

const __unfoldedOriginalRenderReview = renderReview;
renderReview = function(){
  __unfoldedOriginalRenderReview();
  disablePasteForOwnWords(document);
};

function markerNeedsHelp(marker){
  const r = String(marker?.reflection || '').toLowerCase();
  return marker?.type === 'unclear' && (r.includes('i need lecturer help') || r.includes('need lecturer help') || r.includes('i need an example') || /help:\s*[^\n]/.test(r));
}

function lecturerResponseFor(submission, marker){
  const responses = submission?.lecturerResponses || {};
  return responses?.[marker?.code]?.text || responses?.[marker?.code] || '';
}

async function saveLecturerResponse(submissionId, markerCode, studentUid){
  const field = document.querySelector(`[data-response-for="${CSS.escape(submissionId)}|||${CSS.escape(markerCode)}"]`);
  const value = (field?.value || '').trim();
  const payload = value ? {
    text: value,
    markerCode,
    lecturerName: state.lecturerAuth?.displayName || 'Lecturer',
    updatedAt: Date.now()
  } : null;
  try{
    await classRef(`sessions/${submissionId}/lecturerResponses/${markerCode}`).set(payload);
    if(studentUid){
      if(payload){
        await studentRef(studentUid, `lecturerResponses/${submissionId}/${markerCode}`).set(payload);
      }else{
        await studentRef(studentUid, `lecturerResponses/${submissionId}/${markerCode}`).remove();
      }
    }
    toast(value ? 'Lecturer response saved.' : 'Lecturer response removed.', 'success');
  }catch(e){
    console.error(e);
    toast('Response could not be saved. Check Firebase permissions and try again.', 'warning');
  }
}

function attachLecturerResponseHandlers(){
  document.querySelectorAll('[data-save-response]').forEach(btn=>{
    btn.onclick = () => {
      const [submissionId, markerCode, studentUid] = String(btn.dataset.saveResponse || '').split('|||');
      saveLecturerResponse(submissionId, markerCode, studentUid || '');
    };
  });
}

const __unfoldedOriginalRenderLecturerDashboard = renderLecturerDashboard;
renderLecturerDashboard = function(){
  __unfoldedOriginalRenderLecturerDashboard();
  attachLecturerResponseHandlers();
};

renderReflectionList = function(){
  window.__noteStore=[];
  let html="";
  let total=0;
  filteredSubs().forEach(s=>{
    let markers=(s.sharedMarkers||[]).filter(m=>state.selectedViz==="combined"||m.type===state.selectedViz);
    if(!markers.length)return;
    total+=markers.length;
    html+=submissionAudioBlock(s);
    html+=renderSessionAttachments(s);
    html+=markers.map(m=>{
      const needsHelp = markerNeedsHelp(m);
      const response = lecturerResponseFor(s,m);
      const responseKey = `${s.id}|||${m.code}`;
      const studentUid = s.studentUid || '';
      return `<article class="reflection-card ${needsHelp?'needs-help-card':''}"><div class="reflection-card-head"><div><strong>${esc(m.code)} · ${m.type==="unclear"?"Unclear":"Connect"} · ${formatTime(m.time||0)}</strong><p>${m.share==="named"?esc(s.studentName||"Anonymous"):"Anonymous"} · ${esc(s.sessionTitle||"Untitled session")}</p></div>${needsHelp?'<span class="help-request-pill">Needs help</span>':''}</div><p>${esc(m.reflection||"No written reflection shared.")}</p><div class="lecturer-response-box"><label>Lecturer follow-up / support</label><textarea data-response-for="${esc(responseKey)}" placeholder="Write a short explanation, example, or follow-up note for this student.">${esc(response)}</textarea><div class="response-actions"><button type="button" class="btn btn-secondary" data-save-response="${esc(responseKey)}|||${esc(studentUid)}">Save response</button><span class="small-muted">Saved responses are stored with the student submission${studentUid?' and copied to the student dashboard.':'.'}</span></div></div></article>`;
    }).join("");
  });
  return total?html:`<div class="empty-state">No shared reflections yet.</div>`;
};

function flattenStudentResponses(){
  const data = state.lecturerResponses || {};
  const rows=[];
  Object.entries(data).forEach(([submissionId, markers])=>{
    Object.entries(markers || {}).forEach(([markerCode, response])=>{
      if(response && response.text){ rows.push({submissionId, markerCode, ...response}); }
    });
  });
  return rows.sort((a,b)=>(b.updatedAt||0)-(a.updatedAt||0));
}

function injectStudentLecturerResponses(){
  if(!state.studentAuth || state.view !== 'studentProfile') return;
  const existing = document.getElementById('studentLecturerResponses');
  if(existing) existing.remove();
  const rows = flattenStudentResponses();
  if(!rows.length) return;
  const section = document.createElement('section');
  section.id = 'studentLecturerResponses';
  section.className = 'card lecturer-response-student-card';
  section.innerHTML = `<div class="dashboard-header"><div><h3>Lecturer follow-up</h3><p>Responses from your lecturer for moments you shared.</p></div></div><div class="student-response-list">${rows.map(r=>`<article class="student-response-item"><strong>${esc(r.markerCode || 'Marker')} · ${esc(r.lecturerName || 'Lecturer')}</strong><p>${esc(r.text)}</p></article>`).join('')}</div>`;
  const actions = document.querySelector('.dashboard-actions');
  if(actions) actions.parentNode.insertBefore(section, actions);
}

function listenForStudentLecturerResponses(){
  if(!state.studentAuth?.uid || state._listeningResponseUid === state.studentAuth.uid) return;
  state._listeningResponseUid = state.studentAuth.uid;
  studentRef(state.studentAuth.uid, 'lecturerResponses').on('value', snap=>{
    state.lecturerResponses = snap.val() || {};
    if(state.view === 'studentProfile'){
      injectStudentLecturerResponses();
    }
  });
}

const __unfoldedOriginalRenderStudentProfile = renderStudentProfile;
renderStudentProfile = function(){
  __unfoldedOriginalRenderStudentProfile();
  listenForStudentLecturerResponses();
  injectStudentLecturerResponses();
};

if(state.view === 'lecturer') renderLecturerDashboard();
if(state.view === 'studentProfile') renderStudentProfile();

/* v14.1: save lecturer responses without depending on CSS.escape */
async function saveLecturerResponse(submissionId, markerCode, studentUid){
  const wanted = `${submissionId}|||${markerCode}`;
  const field = [...document.querySelectorAll('[data-response-for]')].find(el=>el.dataset.responseFor===wanted);
  const value = (field?.value || '').trim();
  const payload = value ? {
    text: value,
    markerCode,
    lecturerName: state.lecturerAuth?.displayName || 'Lecturer',
    updatedAt: Date.now()
  } : null;
  try{
    await classRef(`sessions/${submissionId}/lecturerResponses/${markerCode}`).set(payload);
    if(studentUid){
      if(payload){
        await studentRef(studentUid, `lecturerResponses/${submissionId}/${markerCode}`).set(payload);
      }else{
        await studentRef(studentUid, `lecturerResponses/${submissionId}/${markerCode}`).remove();
      }
    }
    toast(value ? 'Lecturer response saved.' : 'Lecturer response removed.', 'success');
  }catch(e){
    console.error(e);
    toast('Response could not be saved. Check Firebase permissions and try again.', 'warning');
  }
}
