// UnfoldED Arduino Uno physical buttons
// Wiring:
// Unclear button: one leg to pin 2, other leg to GND
// Connects button: one leg to pin 3, other leg to GND
// Uses INPUT_PULLUP, so no resistor is needed.

const int unclearButtonPin = 2;
const int connectsButtonPin = 3;

bool lastUnclear = HIGH;
bool lastConnects = HIGH;
unsigned long lastUnclearTime = 0;
unsigned long lastConnectsTime = 0;
const unsigned long debounceDelay = 180;

void setup() {
  Serial.begin(9600);
  pinMode(unclearButtonPin, INPUT_PULLUP);
  pinMode(connectsButtonPin, INPUT_PULLUP);
}

void loop() {
  bool unclearNow = digitalRead(unclearButtonPin);
  bool connectsNow = digitalRead(connectsButtonPin);
  unsigned long now = millis();

  // Button is pressed when it changes from HIGH to LOW.
  if (lastUnclear == HIGH && unclearNow == LOW && now - lastUnclearTime > debounceDelay) {
    Serial.println("UNCLEAR");
    lastUnclearTime = now;
  }

  if (lastConnects == HIGH && connectsNow == LOW && now - lastConnectsTime > debounceDelay) {
    Serial.println("CONNECT");
    lastConnectsTime = now;
  }

  lastUnclear = unclearNow;
  lastConnects = connectsNow;
}
